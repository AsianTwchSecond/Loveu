package com.autotrader.mod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

public class CraftingHelper {

    /**
     * Crafts all bones in the player's inventory into bonemeal.
     * Opens the 2x2 crafting grid (inventory screen), places one bone,
     * takes the 3 bonemeal, repeats until no bones left.
     *
     * Since the server is vanilla-ish, we use the player's built-in
     * 2x2 crafting grid (slots 1-4 in PlayerScreenHandler, output slot 0).
     *
     * Slot layout in PlayerScreenHandler:
     *   Slot 0  = crafting output
     *   Slot 1  = crafting grid top-left
     *   Slot 2  = crafting grid top-right
     *   Slot 3  = crafting grid bottom-left
     *   Slot 4  = crafting grid bottom-right
     *   Slots 5-8   = armor
     *   Slots 9-35  = main inventory
     *   Slots 36-44 = hotbar
     *   Slot 45 = offhand
     */
    public static void craftAllBonesToBonemeal(MinecraftClient client) {
        if (client.player == null) return;

        // Open inventory screen if not already open
        if (client.currentScreen == null) {
            client.player.openHandledScreen(client.player.playerScreenHandler);
        }

        PlayerScreenHandler handler = client.player.playerScreenHandler;
        int syncId = handler.syncId;

        // Find all bone slots in main inventory (slots 9-44)
        for (int invSlot = 9; invSlot <= 44; invSlot++) {
            ItemStack stack = handler.getSlot(invSlot).getStack();
            if (stack.isEmpty() || stack.getItem() != Items.BONE) continue;

            // How many bones in this stack
            int boneCount = stack.getCount();

            for (int i = 0; i < boneCount; i++) {
                // 1) Pick up one bone from inventory (right-click to take 1)
                client.interactionManager.clickSlot(syncId, invSlot, 1, SlotActionType.PICKUP, client.player);

                // 2) Place it in crafting slot 1
                client.interactionManager.clickSlot(syncId, 1, 0, SlotActionType.PICKUP, client.player);

                // 3) Shift-click output slot 0 to collect all 3 bonemeal
                client.interactionManager.clickSlot(syncId, 0, 0, SlotActionType.QUICK_MOVE, client.player);
            }
        }

        // Close inventory
        if (client.currentScreen != null) {
            client.currentScreen.close();
        }
    }
}
