package com.autotrader.mod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.util.List;

public class MacroController {

    // ── State machine ──────────────────────────────────────────────
    private enum State {
        IDLE,
        // Shop flow
        OPEN_SHOP,
        WAIT_SHOP_MAIN,
        CLICK_UTILITIES,
        WAIT_SHOP_UTILITIES,
        CLICK_BONE,
        WAIT_CONFIRM_PURCHASE,
        SET_QTY_64,
        CLICK_CONFIRM_BUY,
        WAIT_AFTER_BUY,
        // Crafting flow
        CRAFT_BONEMEAL,
        // Order flow
        OPEN_ORDER,
        WAIT_ORDER_LIST,
        CLICK_ORDER_LISTING,
        WAIT_DELIVER_GUI,
        SHIFT_CLICK_BONEMEAL,
        CLOSE_DELIVER_GUI,
        WAIT_CONFIRM_DELIVERY,
        CLICK_CONFIRM_DELIVERY,
        WAIT_LOOP_DELAY
    }

    private State state = State.IDLE;
    private boolean running = false;

    // How many stacks of 64 bones to buy (12 stacks = 768 bones = 2304 bonemeal)
    private static final int TARGET_BONE_STACKS = 12;
    private int boneStacksBought = 0;

    // Tick counters for waiting
    private int waitTicks = 0;
    private static final int SHORT_WAIT = 10;  // ~0.5s
    private static final int MEDIUM_WAIT = 20; // ~1s
    private static final int LONG_WAIT = 40;   // ~2s

    // ── Public API ─────────────────────────────────────────────────
    public void toggle(MinecraftClient client) {
        running = !running;
        if (running) {
            state = State.OPEN_SHOP;
            boneStacksBought = 0;
            msg(client, "§aAutoTrader started! Press K to stop.");
        } else {
            state = State.IDLE;
            msg(client, "§cAutoTrader stopped.");
        }
    }

    public void tick(MinecraftClient client) {
        if (!running || client.player == null) return;

        // Countdown wait timer
        if (waitTicks > 0) {
            waitTicks--;
            return;
        }

        switch (state) {

            // ── SHOP: open main menu ──────────────────────────────
            case OPEN_SHOP -> {
                sendCommand(client, "shop");
                waitTicks = LONG_WAIT;
                state = State.WAIT_SHOP_MAIN;
            }

            case WAIT_SHOP_MAIN -> {
                if (isScreenOpen(client, "SHOP")) {
                    state = State.CLICK_UTILITIES;
                } else {
                    // Retry
                    state = State.OPEN_SHOP;
                }
            }

            // ── SHOP: click Utilities ─────────────────────────────
            case CLICK_UTILITIES -> {
                int slot = findSlotByName(client, "UTILITIES", "Utilities");
                if (slot >= 0) {
                    clickSlot(client, slot);
                    waitTicks = LONG_WAIT;
                    state = State.WAIT_SHOP_UTILITIES;
                }
            }

            case WAIT_SHOP_UTILITIES -> {
                if (isScreenOpen(client, "SHOP - UTILITIES", "Utilities")) {
                    state = State.CLICK_BONE;
                }
            }

            // ── SHOP: click Bone ──────────────────────────────────
            case CLICK_BONE -> {
                int slot = findSlotByName(client, "Bone");
                if (slot >= 0) {
                    clickSlot(client, slot);
                    waitTicks = LONG_WAIT;
                    state = State.WAIT_CONFIRM_PURCHASE;
                }
            }

            case WAIT_CONFIRM_PURCHASE -> {
                if (isScreenOpen(client, "CONFIRM PURCHASE")) {
                    state = State.SET_QTY_64;
                }
            }

            // ── SHOP: set qty to 64, then confirm ────────────────
            case SET_QTY_64 -> {
                // "Set to 64" button - find green wool / "Set to 64" lore
                int slot = findSlotByName(client, "Set to 64", "64");
                if (slot >= 0) {
                    clickSlot(client, slot);
                    waitTicks = SHORT_WAIT;
                    state = State.CLICK_CONFIRM_BUY;
                } else {
                    // Already at 64 or only one page, just confirm
                    state = State.CLICK_CONFIRM_BUY;
                }
            }

            case CLICK_CONFIRM_BUY -> {
                int slot = findSlotByName(client, "CONFIRM", "Confirm");
                if (slot >= 0) {
                    clickSlot(client, slot);
                    boneStacksBought++;
                    waitTicks = MEDIUM_WAIT;
                    state = State.WAIT_AFTER_BUY;
                }
            }

            case WAIT_AFTER_BUY -> {
                if (boneStacksBought < TARGET_BONE_STACKS) {
                    // Buy again — we should be back at utilities screen
                    if (isScreenOpen(client, "SHOP - UTILITIES", "Utilities")) {
                        state = State.CLICK_BONE;
                    } else if (isScreenOpen(client, "SHOP")) {
                        state = State.CLICK_UTILITIES;
                    } else {
                        // GUI closed, reopen
                        state = State.OPEN_SHOP;
                    }
                } else {
                    // Done buying, close shop and craft
                    closeScreen(client);
                    boneStacksBought = 0;
                    waitTicks = MEDIUM_WAIT;
                    state = State.CRAFT_BONEMEAL;
                }
            }

            // ── CRAFT: bones → bonemeal ───────────────────────────
            case CRAFT_BONEMEAL -> {
                CraftingHelper.craftAllBonesToBonemeal(client);
                waitTicks = LONG_WAIT;
                state = State.OPEN_ORDER;
            }

            // ── ORDER: open Ruleakk's order ───────────────────────
            case OPEN_ORDER -> {
                sendCommand(client, "order Ruleakk");
                waitTicks = LONG_WAIT;
                state = State.WAIT_ORDER_LIST;
            }

            case WAIT_ORDER_LIST -> {
                if (isScreenOpen(client, "ORDERS", "Order")) {
                    state = State.CLICK_ORDER_LISTING;
                } else {
                    state = State.OPEN_ORDER;
                }
            }

            case CLICK_ORDER_LISTING -> {
                // Find "Bone Meal" listing
                int slot = findSlotByName(client, "Bone Meal", "Bone meal", "bonemeal");
                if (slot >= 0) {
                    clickSlot(client, slot);
                    waitTicks = LONG_WAIT;
                    state = State.WAIT_DELIVER_GUI;
                }
            }

            // ── DELIVER: shift-click all bonemeal into chest ──────
            case WAIT_DELIVER_GUI -> {
                if (isScreenOpen(client, "Deliver Items", "DELIVER")) {
                    state = State.SHIFT_CLICK_BONEMEAL;
                }
            }

            case SHIFT_CLICK_BONEMEAL -> {
                shiftClickAllBonemeal(client);
                waitTicks = MEDIUM_WAIT;
                state = State.CLOSE_DELIVER_GUI;
            }

            case CLOSE_DELIVER_GUI -> {
                closeScreen(client);
                waitTicks = LONG_WAIT;
                state = State.WAIT_CONFIRM_DELIVERY;
            }

            // ── CONFIRM DELIVERY ──────────────────────────────────
            case WAIT_CONFIRM_DELIVERY -> {
                if (isScreenOpen(client, "Confirm Delivery", "CONFIRM DELIVERY")) {
                    state = State.CLICK_CONFIRM_DELIVERY;
                } else {
                    // Sometimes GUI takes longer
                    waitTicks = MEDIUM_WAIT;
                }
            }

            case CLICK_CONFIRM_DELIVERY -> {
                // Find green confirm button (NOT the red cancel)
                int slot = findConfirmSlot(client);
                if (slot >= 0) {
                    clickSlot(client, slot);
                    waitTicks = LONG_WAIT;
                    state = State.WAIT_LOOP_DELAY;
                }
            }

            // ── LOOP ──────────────────────────────────────────────
            case WAIT_LOOP_DELAY -> {
                // Small delay between loops to avoid server spam
                waitTicks = 40;
                boneStacksBought = 0;
                state = State.OPEN_SHOP;
                msg(client, "§e[AutoTrader] Loop complete! Starting again...");
            }

            default -> {}
        }
    }

    // ── Helpers ────────────────────────────────────────────────────

    private void sendCommand(MinecraftClient client, String command) {
        if (client.player != null) {
            client.player.networkHandler.sendCommand(command);
        }
    }

    private void msg(MinecraftClient client, String text) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal(text), false);
        }
    }

    private void clickSlot(MinecraftClient client, int slot) {
        if (client.player == null || client.currentScreen == null) return;
        if (!(client.player.currentScreenHandler instanceof GenericContainerScreenHandler handler)) return;
        client.interactionManager.clickSlot(
            handler.syncId, slot, 0, SlotActionType.PICKUP, client.player
        );
    }

    private void closeScreen(MinecraftClient client) {
        if (client.currentScreen != null) {
            client.currentScreen.close();
        }
    }

    /**
     * Check if the currently open GUI title contains any of the given keywords.
     */
    private boolean isScreenOpen(MinecraftClient client, String... titleKeywords) {
        if (!(client.currentScreen instanceof GenericContainerScreen screen)) return false;
        String title = screen.getTitle().getString().toLowerCase();
        for (String kw : titleKeywords) {
            if (title.contains(kw.toLowerCase())) return true;
        }
        return false;
    }

    /**
     * Scan all chest slots and return the first slot whose display name
     * contains any of the given keywords (case-insensitive).
     */
    private int findSlotByName(MinecraftClient client, String... names) {
        if (!(client.player.currentScreenHandler instanceof GenericContainerScreenHandler handler)) return -1;
        int rows = handler.getRows();
        int chestSlots = rows * 9;

        for (int i = 0; i < chestSlots; i++) {
            ItemStack stack = handler.getSlot(i).getStack();
            if (stack.isEmpty()) continue;

            String displayName = stack.getName().getString().toLowerCase();
            // Also check lore lines
            String lore = getLore(stack).toLowerCase();

            for (String name : names) {
                String n = name.toLowerCase();
                if (displayName.contains(n) || lore.contains(n)) {
                    return i;
                }
            }
        }
        return -1;
    }

    /**
     * Find the green CONFIRM button, not the red cancel.
     * We look for lime green wool or an item named CONFIRM whose lore
     * does NOT contain "cancel".
     */
    private int findConfirmSlot(MinecraftClient client) {
        if (!(client.player.currentScreenHandler instanceof GenericContainerScreenHandler handler)) return -1;
        int chestSlots = handler.getRows() * 9;

        for (int i = 0; i < chestSlots; i++) {
            ItemStack stack = handler.getSlot(i).getStack();
            if (stack.isEmpty()) continue;

            // Green stained glass pane or item named CONFIRM
            if (stack.getItem() == Items.LIME_STAINED_GLASS_PANE ||
                stack.getItem() == Items.LIME_WOOL) {
                return i;
            }

            String name = stack.getName().getString().toLowerCase();
            String lore = getLore(stack).toLowerCase();
            if (name.contains("confirm") && !lore.contains("cancel order")) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Shift-click every bonemeal stack in the player inventory into the chest.
     */
    private void shiftClickAllBonemeal(MinecraftClient client) {
        if (!(client.player.currentScreenHandler instanceof GenericContainerScreenHandler handler)) return;
        int totalSlots = handler.slots.size();
        int chestSlots = handler.getRows() * 9;

        // Player inventory slots start after chest slots
        for (int i = chestSlots; i < totalSlots; i++) {
            ItemStack stack = handler.getSlot(i).getStack();
            if (stack.isEmpty()) continue;
            if (stack.getItem() == Items.BONE_MEAL) {
                client.interactionManager.clickSlot(
                    handler.syncId, i, 0, SlotActionType.QUICK_MOVE, client.player
                );
            }
        }
    }

    /**
     * Get all lore lines as a single string.
     */
    private String getLore(ItemStack stack) {
        if (!stack.hasNbt()) return "";
        try {
            var display = stack.getNbt().getCompound("display");
            if (display == null || !display.contains("Lore")) return "";
            var loreList = display.getList("Lore", 8);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < loreList.size(); i++) {
                sb.append(Text.Serialization.fromJson(loreList.getString(i)).getString()).append(" ");
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }
}
